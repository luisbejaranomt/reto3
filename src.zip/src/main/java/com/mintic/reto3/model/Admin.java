package com.mintic.reto3.model;

public class Admin {
}
