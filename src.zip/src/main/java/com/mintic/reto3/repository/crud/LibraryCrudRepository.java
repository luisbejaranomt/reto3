package com.mintic.reto3.repository.crud;

import com.mintic.reto3.model.Library;
import org.springframework.data.repository.CrudRepository;

public interface LibraryCrudRepository extends CrudRepository<Library,Integer> {
}
